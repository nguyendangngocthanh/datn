Công nghệ sử dụng trong dự:
	- PHP/Laravel
	- MySQL
	- HTML/CSS/JS
	- Bootstrap/jQuery
Template:
	- Frotend: